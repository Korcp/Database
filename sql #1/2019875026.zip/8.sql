select name
from movie, movieexec
where studioname=lower('fox') and producerno=certno;
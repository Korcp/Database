select address
from studio
where name =lower('Disney') or name =lower('Mgm')


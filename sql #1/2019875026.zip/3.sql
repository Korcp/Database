select year,length
from movie
where title=lower('coal miner''s daughter');
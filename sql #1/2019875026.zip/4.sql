select starname,birthdate
from movie,starsin,moviestar
where (movieyear=year and starname=name) 
and (year=1980 or title like lower('%of%') or title like lower('%and%'))
order by birthdate DESC;
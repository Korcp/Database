select m1.name
from MovieExec m ,movieexec m1
where m.name=lower('merv Griffin')and m.networth<= m1.networth
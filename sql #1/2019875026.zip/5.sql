select name,address
from movieExec
where networth >= 1000000;
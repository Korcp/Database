select starname
from movie,starsin
where movieyear=1995 and movieyear=year and studioname=lower('Mgm');
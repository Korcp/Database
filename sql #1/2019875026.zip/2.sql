select address,birthdate
from moviestar
where name =lower('Alfred molina');
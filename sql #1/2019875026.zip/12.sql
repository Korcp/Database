select title,length,name
from movie,moviestar,starsin
where 
title=movietitle and starname=name and
gender='female' and birthdate<='1970-01-01' and address like lower('%california%')
ORDER BY length ASC, title DESC;